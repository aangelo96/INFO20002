
How to run file:
    - Use the command line to access the folder
    - Run phase3.py
    - Navigate to "localhost" or 127.0.0.1:80 in your browser